/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lab4ej1;

/**
 *
 * @author Educacionit
 */
public class Empleado {
    private String _nombre;
    private String _dni;
    private int _edad;

    public String getNombre() {
        return _nombre;
    }
    public void setNombre(String nombre) {
        this._nombre = nombre;
    }

    public String getDni() {
        return _dni;
    }
    public void setDni(String dni) {
        this._dni = dni;
    }

    public int getEdad() {
        return _edad;
    }
    public void setEdad(int edad) {
        this._edad = edad;
    }
    
    public Empleado (String nom, String dni, int ed){
        setNombre(nom);
        setDni(dni);
        setEdad(ed);
    }
}
