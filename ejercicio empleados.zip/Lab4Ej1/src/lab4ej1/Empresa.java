/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4ej1;

import java.util.ArrayList;


public class Empresa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Empleado e1 = new Empleado("Joaquin", "34506971", 20);
        Empleado e2 = new Empleado("Ignacio", "34506955", 20);
        Empleado e3 = new Empleado("Romina", "35837041", 19);
        Empleado e4 = new Empleado("Michelle", "38506971", 15);
        Empleado e5 = new Empleado("Nora", "13436315", 53);
        Empleado e6 = new Empleado("Victor", "11912767", 56);

        ArrayList losEmpleados = new ArrayList();

        losEmpleados.add(e1);
        losEmpleados.add(e2);
        losEmpleados.add(e3);
        losEmpleados.add(e4);
        losEmpleados.add(e5);
        losEmpleados.add(e6);

        informarDatosDeEmpleados(losEmpleados);
        int cantDeEmp = losEmpleados.size();
        System.out.println("Cantidad de Empleados: " + cantDeEmp);

        ArrayList Resultado = obtenerDatosDeEmpleadosMenosDe30(losEmpleados);
        informarDatosDeEmpleados(Resultado);
//        informarDatosDeEmpleados(obtenerDatosDeEmpleadosMenosDe30(losEmpleados));

    }

    public static void informarDatosDeEmpleados(ArrayList losEmpleados) {
        for (int i = 0; i < losEmpleados.size(); i++) {
            Empleado e = (Empleado) losEmpleados.get(i);
            System.out.println("Nombre:"+ e.getNombre() +", DNI: "+ e.getDni()+", Edad: "+ e.getEdad());
        }
    }

    public static ArrayList obtenerDatosDeEmpleadosMenosDe30 (ArrayList losEmpleados) {
        ArrayList empleadosMenores30 = new ArrayList();

        for (int i = 0; i < losEmpleados.size(); i++) {
            Empleado e = (Empleado) losEmpleados.get(i);

            if (e.getEdad() < 30) {
                empleadosMenores30.add(e);
            }
        }
        return empleadosMenores30;
    }
}